export { default as SampleApi } from './SampleApi';
