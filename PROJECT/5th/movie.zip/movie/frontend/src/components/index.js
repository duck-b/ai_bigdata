export { default as SampleComponent } from './sample/SampleComponent';
