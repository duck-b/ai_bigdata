/**
 * @name ProductionEnviornment
 * @description 운영 환경 요청 주소
 */
// eslint-disable-next-line
export default {
  base_url: `http://localhost:3333`,
};
