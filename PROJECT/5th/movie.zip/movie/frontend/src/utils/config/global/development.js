// eslint-disable
/**
 * @name DevelopmentEnviornment
 * @description 로컬 개발시 요청 주소
 */
// eslint-disable-next-line
export default {
  base_url: `http://localhost:3333`,
};
