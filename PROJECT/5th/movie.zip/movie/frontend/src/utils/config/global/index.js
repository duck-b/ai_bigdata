import production from './production';
import development from './development';
// eslint-disable-next-line
export default {
  production,
  development,
};
