import React from 'react';
import UserPresenter from './UserPresenter';

const UserContainer = () => {
  return <UserPresenter />;
};

export default UserContainer;
