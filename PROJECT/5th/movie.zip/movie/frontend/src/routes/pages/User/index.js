import UserContainer from './UserContainer';

export default UserContainer;
